// import logo from './logo.svg';
import './App.css';
import React from 'react';
import axios from "axios";

class App extends React.Component {
    token = 'bfa79226b1aaf8272b7bfa64ce9deac8';

    constructor(props) {
        super(props);

        this.state = {
            listCurrencyCode: [],
            listCurrencyRate: [],
            currencyKey: null,
            currency: [],
            amount: 200,
        };

        this.getListCurrencyCode = this.getListCurrencyCode.bind(this);
        this.getListCurrencyRate = this.getListCurrencyRate.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {
        this.getListCurrencyCode();
        this.getListCurrencyRate();
    }

    handleChange(event) {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleSubmit() {
        if (this.state.currencyKey != null) {
            let currencyData = this.state.currency;
            currencyData.push(this.state.currencyKey);
            this.setState({ currency: currencyData })
        }
    }

    handleDelete(index) {
        let currencyData = this.state.currency;
        currencyData.splice(index, 1);
        this.setState({ currency: currencyData })
    }

    async getListCurrencyCode() {
        await axios.get('https://openexchangerates.org/api/currencies.json')
            .then((response) => this.setState({ listCurrencyCode: response.data }))
            .then((error) => console.log(error));
    }

    async getListCurrencyRate() {
        await axios.get(`http://api.exchangeratesapi.io/v1/latest?access_key=${this.token}&format=1`)
            .then((response) => this.setState({ listCurrencyRate: response.data.rates }))
            .catch((error) => console.log(error));
    }

    render() {
        return (
            <>
                <div className='row mt-3 mx-1 mx-md-0'>
                    <div className='col-12 col-md-6 offset-md-3'>
                        <h4 className='primary-font'>Foreign Currency Exchange</h4>

                        <div className='row mt-4'>

                            <div className='col-12 d-flex'>
                                <div className='border py-2 px-3 bg-light'>
                                    EUR
                                </div>
                                <input type="number" className="form-control rounded-0 w-100 h-100" name="amount" id="" placeholder="" value={this.state.amount} onChange={this.handleChange} />
                            </div>

                            <div className='col-12 mt-3'>
                                {this.state.currency.length > 0 ?
                                    this.state.currency.map((currency, index) => (
                                        <div>
                                            <div className='d-flex justify-content-between align-items-center'>
                                                <div>
                                                    <p className='mb-1'>{currency} - {this.state.listCurrencyCode[currency]}</p>
                                                    <p className='m-0 small text-gray'>1 EUR = {currency} {(this.state.listCurrencyRate[currency]).toFixed(2)}</p>
                                                </div>
                                                <div className='d-flex align-items-center'>
                                                    <p className='m-0'>{(this.state.listCurrencyRate[currency] * this.state.amount).toFixed(2)}</p>
                                                    <a href='#' onClick={() => this.handleDelete(index)} className='small ml-3'>Remove</a>
                                                </div>
                                            </div>
                                            <hr />
                                        </div>
                                    ))
                                    :
                                    (<div className='p-3 bg-light text-center rounded text-gray'>No data yet</div>)
                                }

                                <div className='d-flex mt-3'>
                                    <select className="form-control w-50 h-100" name="currencyKey" onChange={this.handleChange}>
                                        <option>Select a currency</option>
                                        {this.state.listCurrencyCode &&
                                            Object.entries(this.state.listCurrencyCode).map(([key, currency], index) => (
                                                <option value={key}>{key}</option>
                                            ))
                                        }
                                    </select>
                                    <button className='btn btn-primary ml-3' onClick={this.handleSubmit}>Add</button>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </>
        );
    }
}

export default App;
